#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自媒体文案生成器核心脚本
支持小红书、知乎、公众号三大平台
"""

import json
import random
import argparse
from datetime import datetime
from typing import Dict, List, Optional

class ContentGenerator:
    """文案生成器主类"""
    
    def __init__(self, platform: str = "xiaohongshu"):
        self.platform = platform
        self.templates = self._load_templates()
        
    def _load_templates(self) -> Dict:
        """加载文案模板"""
        templates = {
            "xiaohongshu": {
                "hooks": [
                    "姐妹们！{topic}真的太重要了😭",
                    "挖到宝了！{topic}这样做效果翻倍✨",
                    "后悔没早点知道！{topic}的正确打开方式💡",
                    "亲测有效！{topic}让我省下一大笔💰",
                    "新手必看！{topic}避坑指南🚫"
                ],
                "emojis": ["✨", "💡", "🔥", "💯", "👇", "😭", "💰", "🎉", "⭐", "❤️"],
                "endings": [
                    "姐妹们觉得有用吗？评论区告诉我👇",
                    "记得点赞收藏，不然找不到了😘",
                    "关注我，分享更多{topic}干货✨",
                    "有问题评论区问，看到都会回💬"
                ],
                "tags": ["#干货分享", "#经验分享", "#实用技巧", "#新手必看", "#避坑指南"]
            },
            "zhihu": {
                "structures": [
                    "直接回答 → 详细解释 → 案例支撑 → 总结",
                    "问题分析 → 方法论 → 实操步骤 → 效果验证",
                    "背景介绍 → 核心观点 → 论据展开 → 行动建议"
                ],
                "phrases": [
                    "先说结论：",
                    "从专业角度分析，",
                    "根据我的经验，",
                    "这里有个关键认知：",
                    "很多人忽略了这一点："
                ]
            },
            "wechat": {
                "openings": [
                    "你有没有遇到过这样的情况...",
                    "今天想和大家聊聊{topic}。",
                    "最近发现一个很厉害的现象...",
                    "先讲个故事。"
                ],
                "transitions": [
                    "为什么这么说呢？",
                    "背后有三个原因：",
                    "这让我想到：",
                    "更关键的是："
                ]
            }
        }
        return templates
    
    def generate_xiaohongshu(self, topic: str, key_points: List[str] = None) -> Dict:
        """生成小红书文案"""
        template = self.templates["xiaohongshu"]
        
        # 生成标题
        titles = [
            f"💄{topic}必看！这{len(key_points or [1,2,3])}个技巧让我从新手变高手✨",
            f"挖到宝了！{topic}这样做效果翻倍💡",
            f"后悔没早点知道！{topic}的正确打开方式🔥",
            f"亲测有效！{topic}让我省下一大笔💰",
            f"新手必看！{topic}避坑指南🚫"
        ]
        
        # 生成正文
        hook = random.choice(template["hooks"]).format(topic=topic)
        content = [hook, ""]
        
        if key_points:
            for i, point in enumerate(key_points[:5], 1):
                emoji = template["emojis"][i % len(template["emojis"])]
                content.append(f"{i}️⃣ **{point}** {emoji}")
                content.append(f"详细说明...\n")
        else:
            for i in range(1, 4):
                emoji = template["emojis"][i % len(template["emojis"])]
                content.append(f"{i}️⃣ **要点{i}** {emoji}")
                content.append(f"这里是关于{topic}的第{i}个重要技巧...\n")
        
        ending = random.choice(template["endings"]).format(topic=topic)
        content.append(ending)
        
        # 生成标签
        tags = template["tags"] + [f"#{topic}", "#经验分享", "#实用技巧"]
        
        return {
            "platform": "小红书",
            "titles": titles,
            "content": "\n".join(content),
            "tags": tags[:15],
            "cover_suggestion": f"{topic}对比图/效果图"
        }
    
    def generate_zhihu(self, question: str, key_points: List[str] = None) -> Dict:
        """生成知乎回答"""
        template = self.templates["zhihu"]
        
        # 生成回答结构
        structure = random.choice(template["structures"])
        
        # 生成正文
        content = []
        content.append(f"**先说结论：** {question}的核心在于...\n")
        content.append("---\n")
        
        if key_points:
            for i, point in enumerate(key_points, 1):
                phrase = template["phrases"][i % len(template["phrases"])]
                content.append(f"### {i}. {point}")
                content.append(f"{phrase}这里展开详细说明...\n")
        else:
            for i in range(1, 4):
                phrase = template["phrases"][i % len(template["phrases"])]
                content.append(f"### {i}. 核心要点{i}")
                content.append(f"{phrase}详细论述...\n")
        
        content.append("---\n")
        content.append("**总结：** 希望以上分享对你有帮助。如果觉得有用，欢迎点赞收藏。有任何问题可以在评论区交流。")
        
        return {
            "platform": "知乎",
            "question": question,
            "structure": structure,
            "content": "\n".join(content),
            "tags": ["相关话题1", "相关话题2", topic]
        }
    
    def generate_wechat(self, topic: str, article_type: str = "干货") -> Dict:
        """生成公众号推文"""
        template = self.templates["wechat"]
        
        # 生成标题
        titles = [
            f"{topic}：2024年最全指南（建议收藏）",
            f"关于{topic}，我花了3年才明白的道理",
            f"{topic}｜看完这篇，你会少走很多弯路",
            f"为什么你的{topic}总是做不好？答案在这里",
            f"{topic}的底层逻辑，一文讲透"
        ]
        
        # 生成大纲
        outline = [
            f"一、为什么{topic}很重要？",
            f"二、{topic}的常见误区",
            f"三、{topic}的正确方法",
            f"四、实操案例分享",
            f"五、总结与行动建议"
        ]
        
        # 生成正文
        opening = random.choice(template["openings"]).format(topic=topic)
        content = [f"{opening}\n", "---\n"]
        
        for section in outline:
            content.append(f"## {section}")
            transition = random.choice(template["transitions"])
            content.append(f"{transition}这里是详细内容...\n")
        
        content.append("---\n")
        content.append("**如果这篇文章对你有帮助，欢迎：**")
        content.append("1. 点赞、在看，让更多人看到")
        content.append("2. 关注公众号，获取更多干货")
        content.append("3. 转发给需要的朋友\n")
        
        return {
            "platform": "公众号",
            "titles": titles,
            "outline": outline,
            "content": "\n".join(content),
            "word_count": "1500-2000字",
            "reading_time": "5-8分钟"
        }
    
    def generate(self, topic: str, platform: Optional[str] = None, **kwargs) -> Dict:
        """主生成入口"""
        platform = platform or self.platform
        
        if platform == "xiaohongshu":
            return self.generate_xiaohongshu(topic, kwargs.get("key_points"))
        elif platform == "zhihu":
            return self.generate_zhihu(topic, kwargs.get("key_points"))
        elif platform == "wechat":
            return self.generate_wechat(topic, kwargs.get("article_type"))
        else:
            raise ValueError(f"不支持的平台: {platform}")

def main():
    parser = argparse.ArgumentParser(description="自媒体文案生成器")
    parser.add_argument("--topic", "-t", required=True, help="文案主题")
    parser.add_argument("--platform", "-p", default="xiaohongshu", 
                       choices=["xiaohongshu", "zhihu", "wechat"],
                       help="目标平台")
    parser.add_argument("--output", "-o", help="输出文件路径")
    parser.add_argument("--format", "-f", default="json", choices=["json", "markdown"],
                       help="输出格式")
    
    args = parser.parse_args()
    
    # 生成文案
    generator = ContentGenerator(args.platform)
    result = generator.generate(args.topic)
    
    # 输出结果
    if args.format == "json":
        output = json.dumps(result, ensure_ascii=False, indent=2)
    else:
        output = f"# {result.get('titles', [args.topic])[0]}\n\n"
        output += result.get("content", "")
    
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(output)
        print(f"文案已保存到: {args.output}")
    else:
        print(output)

if __name__ == "__main__":
    import sys
    import io
    # 设置UTF-8编码
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')
    main()
